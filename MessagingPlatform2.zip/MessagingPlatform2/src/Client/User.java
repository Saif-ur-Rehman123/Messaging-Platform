package Client;

import java.util.ArrayList;

public class User {
    public String name;
    public String fullName;
    public String password;
    public String email;
    public String gender;
    public String phoneNo;
}
